Excel Report App - Final Release

FILES
-----
1. app.py
2. Excel_Upload_Template.xlsx
3. Excel_Report_App_User_Guide.pdf

START
-----
Run the Streamlit app with:
streamlit run app.py

EXCEL UPLOAD HEADINGS
---------------------
The uploaded Excel file must contain these headings exactly:

Date | TIME | Paper code | Paper name | Class | Pattern | Branch | Sem | Stu.No

Do not change the heading names or spelling. Missing or changed headings may cause an error.

USE
---
Upload the Excel file and follow the tabs:
1. DPR + D Form
2. Session Count
3. Date-wise Report
4. Dashboard / Summary

Use the Date Range and Class filters as required.
Use Print Excel or Print PDF for the required report.

For detailed instructions, open:
Excel_Report_App_User_Guide.pdf
